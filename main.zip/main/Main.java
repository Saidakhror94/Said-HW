import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите первое слово");
        String word1 = scanner.next();
        System.out.println("Введите второе слово");
        String word2 = scanner.next();
        int half1 = word1.length() / 2;  // половина первого слова
        int half2 = word2.length() / 2; // половина второго слова
        String result = word1.substring(0, half1) + word2.substring(half2);
        System.out.println(result);

    }
}