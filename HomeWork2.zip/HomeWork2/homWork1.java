//package Homework;
//
//import java.util.Random;
//
//public class homWork1 {
//    public static void main(String[] args) {
//        Random random = new Random();
//        int n = random.nextInt(28801);
//        System.out.println("Ostalos"+n+"second");
//        int hours = n/ 3600;
//        if (hours >0){
//            System.out.println("ost"+hours+"stunden");
//        } else {
//            System.out.println("ostalos mensche chasa");
//        }
//    }
//}
