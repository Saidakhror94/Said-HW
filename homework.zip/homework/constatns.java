package hero;

public class constatns {
        public static final int ELF_POWER = 10;
        public static final int ELF_CHARISMA = 20;
        public static final int ELF_MAGIC = 30;
}
